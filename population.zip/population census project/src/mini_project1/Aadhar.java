package mini_project1;


public class Aadhar {
	public static int aadhar_class;

	public static int getAadhar() {
		return aadhar_class;
	}

	public static void setAadhar(int aadhar) {
		Aadhar.aadhar_class = aadhar;
	}	

}
