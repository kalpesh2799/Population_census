package mini_project1;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class delete
 */
public class delete extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public delete() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
		
		Connection con=DbConnection.connect();
		System.out.print("Hello");
		
		int adhar=Integer.parseInt(request.getParameter("aadhar"));
		
		
		
		
		try{
            response.setContentType("text/html");
           
			
			PreparedStatement pstmt=con.prepareStatement("Delete from user_reg where Aadhar_Card_No=?");
			
			pstmt.setInt(1,adhar);
			
			int i=pstmt.executeUpdate();
			
			Statement stmt=con.createStatement();
	          //ResultSet rs=stmt.executeQuery("select * from user_reg");
	            
	            
	            PrintWriter out=response.getWriter();
	            out.println("<html><body><center>");
	            out.println("<h1><b><u>Record Deleted Successfull....</u></b></h1>");
	            out.println("</center></body></html>");
			
	} catch(Exception e){
		System.out.println(e);
	}
		
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
